//import { Physics } from "phaser";

const config = {
    title: "Hola Phaser",
    type: Phaser.AUTO,
    parent: "contenedor",
    width: 800,
    height: 600,
    scene: {
        preload,
        create,
        update,
    },
   physics: {
       default: 'arcade',
       arcade: {
           gravity: {y: 500},
           debug: false
       }
   }     
};

 var game = new Phaser.Game(config);

function preload (){
    this.load.setBaseURL('http://labs.phaser.io');

    this.load.image('fondo', 'assets/skies/nebula.jpg');
    this.load.image('planeta', 'assets/sprites/phaser1.png');
    this.load.image('particula', 'assets/particles/yellow.png');
};
function create (){
    this.add.image(400, 300, 'fondo');
    //Mundo = this.add.image(400, 250, 'planeta');
    //console.log(this.add.image(400,250,'planeta'));
    Mundo = this.physics.add.image(400, 250, 'planeta');
    console.log(Mundo);
   
    particulas = this.add.particles('particula');
        var emitter = particulas.createEmitter({
            speed: 100,
            scale: {start:1, end:0},
             blendMode: 'ADD'
        });

        Mundo.setAlpha(0.8);
        

    Mundo.setAlpha(0.8);
    Mundo.setAngle(45);
    Mundo.setScale(1);
    //Mundo.setFlipx(true);
    //Mundo.setFlipy(true);
    //Mundo.setRotate(true);
    Mundo.setOrigin(0,0);
    Mundo.setCollideWorldBounds(true);
    Mundo.setBounce(1);
         

// emitter.startFollow(Mundo);

};
function update(time, delta){
    
    Mundo.angle+= 1;  

}; 